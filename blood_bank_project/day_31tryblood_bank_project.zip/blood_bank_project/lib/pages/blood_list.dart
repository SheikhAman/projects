import 'package:blood_bank_project/Models/blood_bank.dart';
import 'package:blood_bank_project/pages/donor_details_page.dart';
import 'package:blood_bank_project/providers/blood_provider.dart';
import'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'login_page.dart';

// import 'login_page.dart';

class BloodBankList extends StatefulWidget {
  static const String routeName = ' /blood_bank_list';

  const BloodBankList({Key? key}) : super(key: key);



  @override
  State<BloodBankList> createState() => _BloodBankListState();
}

class _BloodBankListState extends State<BloodBankList> {


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
            'BloodBank List'
        ),
        actions: [
          PopupMenuButton(
              itemBuilder: (context) => [
                PopupMenuItem(
                  child: TextButton(
                    onPressed: () {
                      Navigator.pushReplacementNamed(context, LoginPage.routeName,
                          arguments: 'Admin Login');
                      // setLoginData(false).then((value) =>
                      //     Navigator.pushReplacementNamed(
                      //         context, LauncherPage.routeName));
                    },
                    child: Text('Admin'),
                  ),
                ),
                PopupMenuItem(
                  child: TextButton(
                    onPressed: () {
                      Navigator.pushReplacementNamed(context, LoginPage.routeName,
                          arguments: 'Donor Login'
                      );

                    },
                    child: Text('Donor'),
                  ),
                ),
                PopupMenuItem(
                  child: TextButton(
                    onPressed: () {
                      Navigator.pushReplacementNamed(context, LoginPage.routeName,
                          arguments: 'User Login'
                      );
                    },
                    child: Text('User'),
                  ),
                ),
              ])
        ],
      ),

      body: Consumer<BloodBankProvider>(
       builder: (context,provider,_) =>   ListView.separated(
            itemBuilder: (context, index){
              final bloodBank = provider.bloodBankList[index];
              return ExpansionPanelList.radio(
                children: [
   ExpansionPanelRadio(
       value: bloodBank.id!,
       headerBuilder: (context, isExpanded) => ListTile(

         title: Text(bloodBank.name),
         subtitle: Text(bloodBank.number),
         onTap: (){
           Navigator.pushNamed(context, DonorDetailsPage.routeName,
           arguments:  bloodBank.id
           );
         },
       ) ,
       body: Row(
         mainAxisAlignment: MainAxisAlignment.spaceEvenly,
         children: [
           IconButton(
               onPressed: (){
                 provider.getCall(bloodBank.number);
               },
               icon: Icon(Icons.call)
           ),
           IconButton(
               onPressed: (){
                 provider.getSms(bloodBank.number);
               },
               icon: Icon(Icons.message),
           ),
           IconButton(
               onPressed: (){
                 provider.getLocation(bloodBank.city);
               },
               icon: Icon(Icons.map),
           )
         ],
       )
   )
                ],
              );
            },
            separatorBuilder: (context,index){
              return Divider(
                height: 1,
                indent: 6,
                endIndent: 6,
                color: Colors.grey.shade600,
              );
            },
            itemCount: provider.bloodBankList.length,
        ),
      )





    );
  }


}
