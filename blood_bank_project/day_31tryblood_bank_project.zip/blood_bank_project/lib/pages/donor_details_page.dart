import 'package:flutter/material.dart';

class DonorDetailsPage extends StatefulWidget {
  static const String routeName = '/donor_details';
  const DonorDetailsPage({Key? key}) : super(key: key);

  @override
  State<DonorDetailsPage> createState() => _DonorDetailsPageState();
}

class _DonorDetailsPageState extends State<DonorDetailsPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Donor Details'),
      ),
    );
  }
}
