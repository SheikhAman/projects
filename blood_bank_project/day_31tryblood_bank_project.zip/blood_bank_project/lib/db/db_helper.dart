import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart' as Path;

import '../Models/blood_bank.dart';

class DBHelper {
  static const String createTableBloodBank = '''
  create table $tableBloodBank(
  $tableBloodBankColId integer primary key,
  $tableBloodBankColName text,
  $tableBloodBankColNumber text,
  $tableBloodBankColPassword text,
  $tableBloodBankColBloodGroup text,
  $tableBloodBankColCity text,
  $tableBloodBankColDob text,
  $tableBloodBankColLbd text,
  $tableBloodBankColGender text,
  $tableBloodBankColImage text,
  $tableBloodBankColFavorite integer
)

''';

// database open and table created
  static Future<Database> open() async {
    final rootPath = await getDatabasesPath();
    final dbPath = Path.join(rootPath, 'bloodbank.db');
    return openDatabase(
      dbPath,
      version: 1,
      onCreate: (db, version)  {
        db.execute(createTableBloodBank);

      },
    );
  }

  // insert method
  static Future<int> insertBloodBank(BloodBankModel bloodBankModel) async {
    final db = await open(); // database open method  called

    print('MODEL :'+bloodBankModel.toString());
    return db.insert(tableBloodBank, bloodBankModel.toMap());
  }

// getting List of map and converting as List of BloodBankModel objects
  static Future<List<BloodBankModel>> getAllBloodBankInfo() async {
    final db = await open();

    final mapList = await db.query(tableBloodBank);
    return List.generate(
        mapList.length, (index) => BloodBankModel.fromMap(mapList[index]));
  }

  // get BloodBank object using id

static Future<BloodBankModel> getBloodBankById(int id) async {
    final db = await open();
    final mapList = await  db.query(tableBloodBank,where: '$tableBloodBankColId = ?',whereArgs: [id]);

    return BloodBankModel.fromMap(mapList.first);
}







}
