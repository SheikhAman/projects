import 'package:blood_bank_project/db/db_helper.dart';
import 'package:flutter/material.dart';
import '../Models/blood_bank.dart';
import 'package:url_launcher/url_launcher.dart';


class BloodBankProvider extends ChangeNotifier {

  List<BloodBankModel> bloodBankList = [];


  getAllBloodList() {
    DBHelper.getAllBloodBankInfo().then((value) {
      bloodBankList = value;
      notifyListeners();
    });
  }

  Future<bool> addNewBlood(BloodBankModel bloodBankModel) async {
    //print('ubyyvy'+bloodBankModel.toString());
    final rowId = await DBHelper.insertBloodBank(bloodBankModel);
    if (rowId > 0) {
      bloodBankModel.id = rowId;
      bloodBankList.add(bloodBankModel);
      print('Bloof Bank List ${bloodBankList.length}');
      bloodBankList.sort((a, b) => a.name.compareTo(b.name));

      notifyListeners();
      return true;
    }

  return false;
}

// get Bloodbank object using id, we are using method from db
  
 Future<BloodBankModel> getBloodBankId(int id) => DBHelper.getBloodBankById(id);










getCall(String number) async{
  final Uri _url = Uri.parse('tel:$number');

  if (!await launchUrl(_url)) {
    throw 'Could not launch $_url';
  }
}

  getSms(String number) async {
    final Uri _url = Uri.parse('sms:$number');

    if (!await launchUrl(_url)) {
      throw 'Could not launch $_url';
    }

  }

  getLocation(String location) async {
    final Uri _url = Uri.parse('geo:0,0?q=$location');

    if (!await launchUrl(_url)) {
      throw 'Could not launch $_url';
    }
  }






}

